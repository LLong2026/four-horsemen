#!/usr/bin/env python3
"""
BIND-1: GitHub <-> DOI binding verifier (deterministic, fail-closed).
Walks the public ledger corpus, extracts every (repo, commit, SHA256, DOI) tuple,
and verifies each leg:
  F1: every commit SHA referenced in the ledger exists in some known repo
  F2: every DOI referenced in the ledger resolves on Zenodo (HTTP 200 via API)
  F3: every recorded SHA256 in the ledger matches the local artifact it names (where present)
  F4: round-trip — a deposited Zenodo file downloads byte-identical to the local artifact
Fail-closed: any unresolvable leg marks the tuple FAILED, never silently green.
Output: BIND-1 manifest JSON + pass/fail summary. Read-only (no writes, no deposits).
"""
import json, re, subprocess, hashlib, os, urllib.request, urllib.error, datetime

WS = "/app/conversations/69b57685ca3719553a34597c"
LEDGER = os.path.join(WS, "fh_pub/LEDGER.md")
# repo set to search for commit objects (all local clones)
REPOS = sorted([d for d in os.listdir(WS)
                if os.path.isdir(os.path.join(WS, d, ".git"))])
results = {"started": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "verifier": "BIND-1 v1.0", "falsifiers": {}, "tuples": [], "notes": []}

def git_has(sha):
    for r in REPOS:
        try:
            t = subprocess.run(["git", "-C", os.path.join(WS, r), "cat-file", "-t", sha],
                               capture_output=True, text=True, timeout=10)
            if t.returncode == 0 and t.stdout.strip() in ("commit", "tag"):
                return r
        except Exception:
            pass
    return None

ledger = open(LEDGER).read()

# ---- F1: commit SHAs referenced in the ledger ----
shas = sorted(set(re.findall(r"\bcommit ([0-9a-f]{7,40})\b", ledger)))
f1 = {}
for sha in shas:
    repo = git_has(sha)
    f1[sha] = repo if repo else "MISSING"
    results["tuples"].append({"type": "ledger->commit", "ref": sha, "found_in": f1[sha],
                              "verdict": "PASS" if repo else "FAIL"})
results["falsifiers"]["F1_commits_resolvable"] = "PASS" if all(v != "MISSING" for v in f1.values()) else "FAIL"
results["notes"].append(f"F1: {len(shas)} ledger commit refs across {len(REPOS)} local repos: {json.dumps(f1)}")

# ---- F2: DOIs resolve on Zenodo ----
dois = sorted(set(re.findall(r"10\.5281/zenodo\.(\d+)", ledger + open(os.path.join(WS, "fh_pub/README.md")).read())))
f2 = {}
for recid in dois:
    url = f"https://zenodo.org/api/records/{recid}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "BIND-1-verifier/1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode())
        title = data.get("metadata", {}).get("title", "")[:90]
        f2[recid] = {"status": "PASS", "http": resp.status, "title": title}
    except urllib.error.HTTPError as e:
        f2[recid] = {"status": "FAIL", "http": e.code, "title": ""}
    except Exception as e:
        f2[recid] = {"status": "FAIL", "http": None, "error": str(e)[:100]}
    results["tuples"].append({"type": "ledger->DOI", "ref": f"10.5281/zenodo.{recid}",
                              "verdict": f2[recid]["status"], "detail": f2[recid].get("title") or f2[recid].get("error")})
results["falsifiers"]["F2_dois_resolve"] = "PASS" if all(v["status"] == "PASS" for v in f2.values()) else "FAIL"
results["notes"].append(f"F2: {len(dois)} unique DOIs checked via Zenodo API")

# ---- F3: recorded SHA256s vs local artifacts ----
# CCR-1 recorded results hash (from ledger entry 0032)
CCR1_LOCAL = os.path.join(WS, "penta_v2/containment_test")
f3 = []
expected = "91293bf00cb4a380b3b4f54e4e8412c2c9294798eca46d9524a1a04582bea230"
candidates = []
if os.path.isdir(CCR1_LOCAL):
    for fn in os.listdir(CCR1_LOCAL):
        if fn.endswith(".json"):
            candidates.append(os.path.join(CCR1_LOCAL, fn))
found_hash_match = None
for c in candidates:
    h = hashlib.sha256(open(c, "rb").read()).hexdigest()
    if h == expected:
        found_hash_match = c
        break
f3.append({"artifact": "CCR-1 machine results JSON", "expected_sha256": expected,
           "match_path": found_hash_match, "verdict": "PASS" if found_hash_match else "UNVERIFIED-LOCALLY"})
results["tuples"].append({"type": "ledger->sha256", "ref": "CCR-1 results hash", "verdict": f3[-1]["verdict"]})
results["falsifiers"]["F3_hash_chain_local"] = f3[-1]["verdict"]
results["notes"].append(f"F3: CCR-1 recorded hash {'matched' if found_hash_match else 'not matched'} among {len(candidates)} local candidates")

# ---- F4: round-trip on one deposited file ----
f4 = {"verdict": "SKIP", "detail": "no candidate"}
recid = "23288189"  # CCR-1
try:
    req = urllib.request.Request(f"https://zenodo.org/api/records/{recid}", headers={"User-Agent": "BIND-1-verifier/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        meta = json.loads(resp.read().decode())
    files = meta.get("files", [])
    if files:
        dl = files[0]
        furl, fchk, fn = dl["links"]["self"], (dl.get("checksum") or "").replace("md5:", ""), dl["key"]
        req2 = urllib.request.Request(furl, headers={"User-Agent": "BIND-1-verifier/1.0"})
        with urllib.request.urlopen(req2, timeout=120) as resp2:
            blob = resp2.read()
        local_md5 = hashlib.md5(blob).hexdigest()
        match = (local_md5 == fchk)
        # also compare with local evidence bundle if the same filename exists
        local_cand = None
        for root, dirs, fs_ in os.walk(os.path.join(WS, "fh_pub")):
            for x in fs_:
                if x == fn:
                    local_cand = os.path.join(root, x)
        same_as_local = None
        if local_cand:
            same_as_local = (open(local_cand, "rb").read() == blob)
        f4 = {"verdict": "PASS" if match else "FAIL", "file": fn,
              "zenodo_md5": fchk, "download_md5": local_md5,
              "byte_identical_to_local": same_as_local, "local_path": local_cand}
    else:
        f4 = {"verdict": "FAIL", "detail": "record exposes no files (restricted?)"}
except Exception as e:
    f4 = {"verdict": "FAIL", "detail": str(e)[:200]}
results["falsifiers"]["F4_roundtrip_download"] = f4["verdict"]
results["notes"].append(f"F4: round-trip on CCR-1 deposited file: {json.dumps(f4)[:400]}")
results["tuples"].append({"type": "DOI->bytes round-trip", "ref": recid, "verdict": f4["verdict"]})

results["finished"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
all_f = list(results["falsifiers"].values())
results["overall"] = "ALL PASS" if all(v == "PASS" for v in all_f) else ("FALSIFIERS TRIPPED" if "FAIL" in all_f else "PASS WITH CAVEATS")
out = os.path.join(WS, "bind1_binding_receipt_20261013.json")
json.dump(results, open(out, "w"), indent=2)
print(json.dumps({"overall": results["overall"], "falsifiers": results["falsifiers"],
                  "receipt": out}, indent=2))
