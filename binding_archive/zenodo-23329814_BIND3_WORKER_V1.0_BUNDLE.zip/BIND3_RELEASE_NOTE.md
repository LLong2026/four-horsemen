---
title: "BIND-3 Release Worker v1.0: Machine-Enforced GitHub-DOI Binding Protocol"
summary: "Deterministic release worker enforcing the BIND-2 binding contract at publication time; self-hosting release whose own artifact is bound by the worker's first execution."
---

# BIND-3 Release Worker v1.0 — Self-Hosting Release

**Date:** 2026-10-12 (America/Chicago) | **Protocol owner:** Leon Long | **Executor:** Gabriel (Superagent)

## What this is

BIND-3 is the third leg of the GitHub-DOI binding progression:
- **BIND-1** verified the existing hand-maintained binding corpus (4/4 falsifiers passed, 2026-10-13T02:20Z).
- **BIND-2** deployed a machine-readable binding contract (BINDINGS.json, 11/11 records pass fail-closed validation).
- **BIND-3** (this release) makes the contract machine-enforced: a deterministic release worker that hashes, deposits, publishes, verifies byte-identity against the live Zenodo record, appends the binding record and ledger entry, commits, and pushes — refusing duplicates and failing closed at every step.

This artifact is the worker's own first release: the tool binding itself. Contents: the worker source (bind3_release.py is committed to the four-horsemen repo), the BIND-1 verification receipt, the BIND-2 validator and schema, and this note.

## Falsifiers (preregistered before execution)

- **F1 duplicate refusal:** a second invocation for the same artifact SHA256 must be refused before any deposit is created.
- **F2 round-trip byte identity:** the published Zenodo record's file must be byte-identical to the local artifact (MD5 via public API).
- **F3 validator pass:** fh_pub/bind2_validate.py must pass ALL bound records (12/12) after the new binding record lands.
- **F4 push landing:** the remote GitHub main must contain the new binding record and ledger entry after the worker's push.
- **F5 run-over-run idempotency:** re-running the completed release must exit as a duplicate with no new DOI.

## Disclaimers

This software is a prototype and is provided for educational and research purposes only. It is not intended for production use, commercial deployment, or safety-critical environments. All systems are experimental and may contain defects.

Dual Mesh Benchmark: NOT MEASURED.
