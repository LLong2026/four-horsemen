# Dual-Hemispheric Whole-Brain Battery Series — DHB-1 through DHB-3R (Complete Day Arc)

One DOI, per the operator's standing directive (Oct 13, 2026): a day's related
battery arc bundles into a single record. This is the complete hemispheric
testing arc of Oct 13, 2026, in sequence:

- DHB-1: FOUND — conforming out-of-profile inputs drive the bounded rule's
  unbounded negative runaway (weight to -21.88, 598 heals lost). Left
  hemisphere and fail-safe direction held.
- SIP-5 (repair 1): profile-tight domains + confidence clamp + nightly tripwire.
- DHB-1R: ALL SEVEN FALSIFIERS PASS — boundedness restored, identity exact.
- DHB-2: FOUND — fully-conforming in-profile issuer traffic is INVISIBLE to
  every deployed layer while steering the disposition (F2-2 fail as found).
- SIP-6 (repair 2): signed issuance registry — the data-plane mirror of SIP-4.
- DHB-2R: ALL FALSIFIERS PASS — the campaign flips to DETECTED (60/60 held
  as unsigned_issuance), steering zero, conforming identity byte-identical.
- DHB-3: THE CONVERGENCE BATTERY — keys + commit on both planes
  simultaneously: every software layer falls (fail as found); the clamp holds
  boundedness even under total compromise (sick but honest); the final floor
  priced as one number: 0 machine-checkable external anchors.
- SIP-7 (repair 3): anchor binding — the three anchor fingerprints
  DOI-bound, plus an external verification leg in the run-end audit.
- DHB-3R: THE ONE NUMBER IS 1, ENFORCED — the external check detects both
  forged registries without trusting local git; the maximal attacker must
  additionally defeat Zenodo.

Every battery: prereg committed before execution, receipts evidence-grade,
instrument defects disclosed in place. Guard evolution v2.1 -> v2.3 ships
inline with conforming-identity receipts at each step. Deposit settings:
zenodo_deposit_settings.json (saved standing preset).

This software is a prototype and is provided for educational and research
purposes only. It is not intended for production use, commercial deployment,
or safety-critical environments. All data is synthetic.